﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalLinq.Models
{
    public class ToysContext:DbContext
    {
        public virtual DbSet<User> Users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=EMAN\\SQLEXPRESS;Database=ToysStore;Trusted_Connection=True;Trust server certificate=True");
        }
    }
}
