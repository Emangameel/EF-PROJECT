﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalLinq.Models
{
    public class UserManager
    {
        public bool RegisterUser(string username, string password, string confirmPassword, string email, string phone)
        {
            using (var context = new ToysContext())
            {
                if (context.Users.Any(u => u.Name == username))
                {
                    MessageBox.Show("Username already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (context.Users.Any(u => u.Email == email))
                {
                    MessageBox.Show("Email already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (context.Users.Any(u => u.PhoneNumber == phone))
                {
                    MessageBox.Show("Phone number already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (password != confirmPassword)
                {
                    MessageBox.Show("Passwords do not match.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (!IsValidEmail(email))
                {
                    MessageBox.Show("Invalid email format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (!IsValidPhone(phone))
                {
                    MessageBox.Show("Invalid phone number format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                string hashedPassword = password;

                var newUser = new User
                {
                    Name = username,
                    Password = hashedPassword,
                    Email = email,
                    PhoneNumber = phone
                };

                context.Users.Add(newUser);
                context.SaveChanges();

                return true;
            }
        }

        private bool IsValidEmail(string email)
        {
            return email.Contains("@") && email.Contains(".");
        }

        private bool IsValidPhone(string phone)
        {
            return phone.Length == 11 && phone.All(char.IsDigit);
     
        }
       


    }
}
